import type { PropertyDef as $PropertyDef } from '@osdk/client';
import { $osdkMetadata } from '../../OntologyMetadata.js';
import type { LoanDocument } from './LoanDocument.js';
import type { ObjectTypeDefinition as $ObjectTypeDefinition, ObjectMetadata as $ObjectMetadata } from '@osdk/client';
import type { ObjectSet as $ObjectSet, Osdk as $Osdk, PropertyValueWireToClient as $PropType } from '@osdk/client';
export declare namespace LoanInformation {
    type PropertyKeys = 'borrowerName' | 'cashout' | 'cema' | 'closingAgent' | 'division' | 'docType' | 'firstPaymentDate' | 'fundingReworkTi' | 'id' | 'interestRate' | 'loanAmount' | 'loanCloserName' | 'loanNumber' | 'loanPurpose' | 'loanStatus' | 'loanStatusId' | 'loanType' | 'occupancy' | 'payoffShortageTi' | 'product' | 'propertyAddress' | 'propertyType' | 'scheduledClosingDate' | 'scheduledDisbursementDate' | 'supportCenter';
    interface Links {
        readonly loanDocuments: LoanDocument.ObjectSet;
    }
    interface Props {
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Borrower Name'
         */
        readonly borrowerName: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Cashout'
         */
        readonly cashout: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Cema'
         */
        readonly cema: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Closing Agent'
         */
        readonly closingAgent: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Division'
         */
        readonly division: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Doc Type'
         */
        readonly docType: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'First Payment Date'
         */
        readonly firstPaymentDate: $PropType['datetime'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Funding Rework TI'
         */
        readonly fundingReworkTi: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Id'
         */
        readonly id: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Interest Rate'
         */
        readonly interestRate: $PropType['double'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Loan Amount'
         */
        readonly loanAmount: $PropType['integer'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Loan Closer Name'
         */
        readonly loanCloserName: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Loan Number'
         */
        readonly loanNumber: $PropType['string'];
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Loan Purpose'
         */
        readonly loanPurpose: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Loan Status'
         */
        readonly loanStatus: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Loan Status Id'
         */
        readonly loanStatusId: $PropType['integer'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Loan Type'
         */
        readonly loanType: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Occupancy'
         */
        readonly occupancy: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Payoff Shortage TI'
         */
        readonly payoffShortageTi: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Product'
         */
        readonly product: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Property Address'
         */
        readonly propertyAddress: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Property Type'
         */
        readonly propertyType: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Scheduled Closing Date'
         */
        readonly scheduledClosingDate: $PropType['datetime'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Scheduled Disbursement Date'
         */
        readonly scheduledDisbursementDate: $PropType['datetime'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Support Center'
         */
        readonly supportCenter: $PropType['string'] | undefined;
    }
    type StrictProps = Props;
    interface ObjectSet extends $ObjectSet<LoanInformation, LoanInformation.ObjectSet> {
    }
    type OsdkInstance<OPTIONS extends never | '$rid' = never, K extends keyof LoanInformation.Props = keyof LoanInformation.Props> = $Osdk.Instance<LoanInformation, OPTIONS, K>;
    /** @deprecated use OsdkInstance */
    type OsdkObject<OPTIONS extends never | '$rid' = never, K extends keyof LoanInformation.Props = keyof LoanInformation.Props> = OsdkInstance<OPTIONS, K>;
}
export interface LoanInformation extends $ObjectTypeDefinition {
    osdkMetadata: typeof $osdkMetadata;
    type: 'object';
    apiName: 'LoanInformation';
    primaryKeyApiName: 'loanNumber';
    primaryKeyType: 'string';
    __DefinitionMetadata?: {
        objectSet: LoanInformation.ObjectSet;
        props: LoanInformation.Props;
        linksType: LoanInformation.Links;
        strictProps: LoanInformation.StrictProps;
        apiName: 'LoanInformation';
        description: 'Loan Information';
        displayName: 'Loan Information';
        icon: {
            type: 'blueprint';
            color: '#4C90F0';
            name: 'cube';
        };
        implements: [];
        interfaceMap: {};
        inverseInterfaceMap: {};
        links: {
            loanDocuments: $ObjectMetadata.Link<LoanDocument, true>;
        };
        pluralDisplayName: 'Loan Informations';
        primaryKeyApiName: 'loanNumber';
        primaryKeyType: 'string';
        properties: {
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Borrower Name'
             */
            borrowerName: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Cashout'
             */
            cashout: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Cema'
             */
            cema: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Closing Agent'
             */
            closingAgent: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Division'
             */
            division: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Doc Type'
             */
            docType: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'First Payment Date'
             */
            firstPaymentDate: $PropertyDef<'datetime', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Funding Rework TI'
             */
            fundingReworkTi: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Id'
             */
            id: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Interest Rate'
             */
            interestRate: $PropertyDef<'double', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Loan Amount'
             */
            loanAmount: $PropertyDef<'integer', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Loan Closer Name'
             */
            loanCloserName: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Loan Number'
             */
            loanNumber: $PropertyDef<'string', 'non-nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Loan Purpose'
             */
            loanPurpose: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Loan Status'
             */
            loanStatus: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Loan Status Id'
             */
            loanStatusId: $PropertyDef<'integer', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Loan Type'
             */
            loanType: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Occupancy'
             */
            occupancy: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Payoff Shortage TI'
             */
            payoffShortageTi: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Product'
             */
            product: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Property Address'
             */
            propertyAddress: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Property Type'
             */
            propertyType: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Scheduled Closing Date'
             */
            scheduledClosingDate: $PropertyDef<'datetime', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Scheduled Disbursement Date'
             */
            scheduledDisbursementDate: $PropertyDef<'datetime', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Support Center'
             */
            supportCenter: $PropertyDef<'string', 'nullable', 'single'>;
        };
        rid: 'ri.ontology.main.object-type.5ce99d19-1aa8-4887-98d6-2955bfb8fd78';
        status: 'EXPERIMENTAL';
        titleProperty: 'loanNumber';
        type: 'object';
        visibility: 'NORMAL';
    };
}
export declare const LoanInformation: LoanInformation;
