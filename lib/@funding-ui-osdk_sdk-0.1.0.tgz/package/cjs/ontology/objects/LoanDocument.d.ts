import type { PropertyDef as $PropertyDef } from '@osdk/client';
import { $osdkMetadata } from '../../OntologyMetadata.js';
import type { LoanInformation } from './LoanInformation.js';
import type { ObjectTypeDefinition as $ObjectTypeDefinition, ObjectMetadata as $ObjectMetadata } from '@osdk/client';
import type { ObjectSet as $ObjectSet, Osdk as $Osdk, PropertyValueWireToClient as $PropType, SingleLinkAccessor as $SingleLinkAccessor } from '@osdk/client';
export declare namespace LoanDocument {
    type PropertyKeys = 'description' | 'documentName' | 'id' | 'loanDocuments' | 'loanNumber' | 'uploadedDateTime';
    interface Links {
        readonly loanInformation: $SingleLinkAccessor<LoanInformation>;
    }
    interface Props {
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Description'
         */
        readonly description: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Document Name'
         */
        readonly documentName: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Id'
         */
        readonly id: $PropType['string'];
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Loan Documents'
         */
        readonly loanDocuments: $PropType['attachment'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Loan Number'
         */
        readonly loanNumber: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Uploaded DateTime'
         */
        readonly uploadedDateTime: $PropType['timestamp'] | undefined;
    }
    type StrictProps = Props;
    interface ObjectSet extends $ObjectSet<LoanDocument, LoanDocument.ObjectSet> {
    }
    type OsdkInstance<OPTIONS extends never | '$rid' = never, K extends keyof LoanDocument.Props = keyof LoanDocument.Props> = $Osdk.Instance<LoanDocument, OPTIONS, K>;
    /** @deprecated use OsdkInstance */
    type OsdkObject<OPTIONS extends never | '$rid' = never, K extends keyof LoanDocument.Props = keyof LoanDocument.Props> = OsdkInstance<OPTIONS, K>;
}
export interface LoanDocument extends $ObjectTypeDefinition {
    osdkMetadata: typeof $osdkMetadata;
    type: 'object';
    apiName: 'LoanDocument';
    primaryKeyApiName: 'id';
    primaryKeyType: 'string';
    __DefinitionMetadata?: {
        objectSet: LoanDocument.ObjectSet;
        props: LoanDocument.Props;
        linksType: LoanDocument.Links;
        strictProps: LoanDocument.StrictProps;
        apiName: 'LoanDocument';
        description: '';
        displayName: 'Loan Document';
        icon: {
            type: 'blueprint';
            color: '#4C90F0';
            name: 'cube';
        };
        implements: [];
        interfaceMap: {};
        inverseInterfaceMap: {};
        links: {
            loanInformation: $ObjectMetadata.Link<LoanInformation, false>;
        };
        pluralDisplayName: 'Loan Documents';
        primaryKeyApiName: 'id';
        primaryKeyType: 'string';
        properties: {
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Description'
             */
            description: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Document Name'
             */
            documentName: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Id'
             */
            id: $PropertyDef<'string', 'non-nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Loan Documents'
             */
            loanDocuments: $PropertyDef<'attachment', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Loan Number'
             */
            loanNumber: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Uploaded DateTime'
             */
            uploadedDateTime: $PropertyDef<'timestamp', 'nullable', 'single'>;
        };
        rid: 'ri.ontology.main.object-type.4109c6d7-7869-44c8-9264-f1f6fead0900';
        status: 'EXPERIMENTAL';
        titleProperty: 'loanNumber';
        type: 'object';
        visibility: 'NORMAL';
    };
}
export declare const LoanDocument: LoanDocument;
