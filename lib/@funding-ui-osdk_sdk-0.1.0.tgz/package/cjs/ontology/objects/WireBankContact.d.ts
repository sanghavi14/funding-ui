import type { PropertyDef as $PropertyDef } from '@osdk/client';
import { $osdkMetadata } from '../../OntologyMetadata.js';
import type { ObjectTypeDefinition as $ObjectTypeDefinition } from '@osdk/client';
import type { ObjectSet as $ObjectSet, Osdk as $Osdk, PropertyValueWireToClient as $PropType } from '@osdk/client';
export declare namespace WireBankContact {
    type PropertyKeys = 'abaNum' | 'accountName' | 'accountNum' | 'addressType' | 'city' | 'id' | 'loanNumber' | 'name' | 'shortName' | 'state' | 'zipPlus';
    type Links = {};
    interface Props {
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Aba Num'
         */
        readonly abaNum: $PropType['integer'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Account Name'
         */
        readonly accountName: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Account Num'
         */
        readonly accountNum: $PropType['long'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Address Type'
         */
        readonly addressType: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'City'
         */
        readonly city: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Id'
         */
        readonly id: $PropType['string'];
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Loan Number'
         */
        readonly loanNumber: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Name'
         */
        readonly name: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Short Name'
         */
        readonly shortName: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'State'
         */
        readonly state: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Zip Plus'
         */
        readonly zipPlus: $PropType['string'] | undefined;
    }
    type StrictProps = Props;
    interface ObjectSet extends $ObjectSet<WireBankContact, WireBankContact.ObjectSet> {
    }
    type OsdkInstance<OPTIONS extends never | '$rid' = never, K extends keyof WireBankContact.Props = keyof WireBankContact.Props> = $Osdk.Instance<WireBankContact, OPTIONS, K>;
    /** @deprecated use OsdkInstance */
    type OsdkObject<OPTIONS extends never | '$rid' = never, K extends keyof WireBankContact.Props = keyof WireBankContact.Props> = OsdkInstance<OPTIONS, K>;
}
export interface WireBankContact extends $ObjectTypeDefinition {
    osdkMetadata: typeof $osdkMetadata;
    type: 'object';
    apiName: 'WireBankContact';
    primaryKeyApiName: 'id';
    primaryKeyType: 'string';
    __DefinitionMetadata?: {
        objectSet: WireBankContact.ObjectSet;
        props: WireBankContact.Props;
        linksType: WireBankContact.Links;
        strictProps: WireBankContact.StrictProps;
        apiName: 'WireBankContact';
        description: 'Wire Bank Contact ';
        displayName: 'Wire Bank Contact';
        icon: {
            type: 'blueprint';
            color: '#4C90F0';
            name: 'cube';
        };
        implements: [];
        interfaceMap: {};
        inverseInterfaceMap: {};
        links: {};
        pluralDisplayName: 'Wire Bank Contacts';
        primaryKeyApiName: 'id';
        primaryKeyType: 'string';
        properties: {
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Aba Num'
             */
            abaNum: $PropertyDef<'integer', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Account Name'
             */
            accountName: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Account Num'
             */
            accountNum: $PropertyDef<'long', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Address Type'
             */
            addressType: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'City'
             */
            city: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Id'
             */
            id: $PropertyDef<'string', 'non-nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Loan Number'
             */
            loanNumber: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Name'
             */
            name: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Short Name'
             */
            shortName: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'State'
             */
            state: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Zip Plus'
             */
            zipPlus: $PropertyDef<'string', 'nullable', 'single'>;
        };
        rid: 'ri.ontology.main.object-type.0a3000cc-a971-49c2-8d06-1985ba46ee87';
        status: 'EXPERIMENTAL';
        titleProperty: 'loanNumber';
        type: 'object';
        visibility: 'NORMAL';
    };
}
export declare const WireBankContact: WireBankContact;
