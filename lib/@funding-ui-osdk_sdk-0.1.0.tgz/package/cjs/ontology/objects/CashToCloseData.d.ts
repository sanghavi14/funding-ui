import type { PropertyDef as $PropertyDef } from '@osdk/client';
import { $osdkMetadata } from '../../OntologyMetadata.js';
import type { ObjectTypeDefinition as $ObjectTypeDefinition } from '@osdk/client';
import type { ObjectSet as $ObjectSet, Osdk as $Osdk, PropertyValueWireToClient as $PropType } from '@osdk/client';
export declare namespace CashToCloseData {
    type PropertyKeys = 'actualAmt' | 'cashToBrUwApprove' | 'cashToClose' | 'escrShortageAmt' | 'id' | 'liquidAssetAvail' | 'loanNummber' | 'maxLoanAmt' | 'minLoanAmt' | 'proposedPmt';
    type Links = {};
    interface Props {
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Actual Amt'
         */
        readonly actualAmt: $PropType['integer'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Cash To Br Uw Approve'
         */
        readonly cashToBrUwApprove: $PropType['integer'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Cash To Close'
         */
        readonly cashToClose: $PropType['integer'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Escr Shortage Amt'
         */
        readonly escrShortageAmt: $PropType['integer'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Id'
         */
        readonly id: $PropType['string'];
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Liquid Asset Avail'
         */
        readonly liquidAssetAvail: $PropType['integer'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Loan Nummber'
         */
        readonly loanNummber: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Max Loan Amt'
         */
        readonly maxLoanAmt: $PropType['integer'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Min Loan Amt'
         */
        readonly minLoanAmt: $PropType['integer'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Proposed Pmt'
         */
        readonly proposedPmt: $PropType['integer'] | undefined;
    }
    type StrictProps = Props;
    interface ObjectSet extends $ObjectSet<CashToCloseData, CashToCloseData.ObjectSet> {
    }
    type OsdkInstance<OPTIONS extends never | '$rid' = never, K extends keyof CashToCloseData.Props = keyof CashToCloseData.Props> = $Osdk.Instance<CashToCloseData, OPTIONS, K>;
    /** @deprecated use OsdkInstance */
    type OsdkObject<OPTIONS extends never | '$rid' = never, K extends keyof CashToCloseData.Props = keyof CashToCloseData.Props> = OsdkInstance<OPTIONS, K>;
}
export interface CashToCloseData extends $ObjectTypeDefinition {
    osdkMetadata: typeof $osdkMetadata;
    type: 'object';
    apiName: 'CashToCloseData';
    primaryKeyApiName: 'id';
    primaryKeyType: 'string';
    __DefinitionMetadata?: {
        objectSet: CashToCloseData.ObjectSet;
        props: CashToCloseData.Props;
        linksType: CashToCloseData.Links;
        strictProps: CashToCloseData.StrictProps;
        apiName: 'CashToCloseData';
        description: 'Cash To Close Data';
        displayName: 'Cash To Close';
        icon: {
            type: 'blueprint';
            color: '#4C90F0';
            name: 'cube';
        };
        implements: [];
        interfaceMap: {};
        inverseInterfaceMap: {};
        links: {};
        pluralDisplayName: 'CashToCloseData';
        primaryKeyApiName: 'id';
        primaryKeyType: 'string';
        properties: {
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Actual Amt'
             */
            actualAmt: $PropertyDef<'integer', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Cash To Br Uw Approve'
             */
            cashToBrUwApprove: $PropertyDef<'integer', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Cash To Close'
             */
            cashToClose: $PropertyDef<'integer', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Escr Shortage Amt'
             */
            escrShortageAmt: $PropertyDef<'integer', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Id'
             */
            id: $PropertyDef<'string', 'non-nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Liquid Asset Avail'
             */
            liquidAssetAvail: $PropertyDef<'integer', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Loan Nummber'
             */
            loanNummber: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Max Loan Amt'
             */
            maxLoanAmt: $PropertyDef<'integer', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Min Loan Amt'
             */
            minLoanAmt: $PropertyDef<'integer', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Proposed Pmt'
             */
            proposedPmt: $PropertyDef<'integer', 'nullable', 'single'>;
        };
        rid: 'ri.ontology.main.object-type.d0f2d518-4508-472c-94cd-4de84a0c0e00';
        status: 'EXPERIMENTAL';
        titleProperty: 'id';
        type: 'object';
        visibility: 'NORMAL';
    };
}
export declare const CashToCloseData: CashToCloseData;
