import type { PropertyDef as $PropertyDef } from '@osdk/client';
import { $osdkMetadata } from '../../OntologyMetadata.js';
import type { ObjectTypeDefinition as $ObjectTypeDefinition } from '@osdk/client';
import type { ObjectSet as $ObjectSet, Osdk as $Osdk, PropertyValueWireToClient as $PropType } from '@osdk/client';
export declare namespace TrackingItem {
    type PropertyKeys = 'dueDate' | 'hasException' | 'id' | 'loanNumber' | 'priorTo' | 'tiName' | 'tiStatus';
    type Links = {};
    interface Props {
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Due Date'
         */
        readonly dueDate: $PropType['datetime'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Has Exception'
         */
        readonly hasException: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Id'
         */
        readonly id: $PropType['string'];
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Loan Number'
         */
        readonly loanNumber: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Prior To'
         */
        readonly priorTo: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Ti Name'
         */
        readonly tiName: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Ti Status'
         */
        readonly tiStatus: $PropType['string'] | undefined;
    }
    type StrictProps = Props;
    interface ObjectSet extends $ObjectSet<TrackingItem, TrackingItem.ObjectSet> {
    }
    type OsdkInstance<OPTIONS extends never | '$rid' = never, K extends keyof TrackingItem.Props = keyof TrackingItem.Props> = $Osdk.Instance<TrackingItem, OPTIONS, K>;
    /** @deprecated use OsdkInstance */
    type OsdkObject<OPTIONS extends never | '$rid' = never, K extends keyof TrackingItem.Props = keyof TrackingItem.Props> = OsdkInstance<OPTIONS, K>;
}
export interface TrackingItem extends $ObjectTypeDefinition {
    osdkMetadata: typeof $osdkMetadata;
    type: 'object';
    apiName: 'TrackingItem';
    primaryKeyApiName: 'id';
    primaryKeyType: 'string';
    __DefinitionMetadata?: {
        objectSet: TrackingItem.ObjectSet;
        props: TrackingItem.Props;
        linksType: TrackingItem.Links;
        strictProps: TrackingItem.StrictProps;
        apiName: 'TrackingItem';
        description: 'Tracking Item is use for Loan';
        displayName: 'Tracking Item';
        icon: {
            type: 'blueprint';
            color: '#4C90F0';
            name: 'cube';
        };
        implements: [];
        interfaceMap: {};
        inverseInterfaceMap: {};
        links: {};
        pluralDisplayName: 'Tracking Items';
        primaryKeyApiName: 'id';
        primaryKeyType: 'string';
        properties: {
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Due Date'
             */
            dueDate: $PropertyDef<'datetime', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Has Exception'
             */
            hasException: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Id'
             */
            id: $PropertyDef<'string', 'non-nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Loan Number'
             */
            loanNumber: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Prior To'
             */
            priorTo: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Ti Name'
             */
            tiName: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Ti Status'
             */
            tiStatus: $PropertyDef<'string', 'nullable', 'single'>;
        };
        rid: 'ri.ontology.main.object-type.5b2661d2-d6e8-4dea-9d10-751c60a6e374';
        status: 'EXPERIMENTAL';
        titleProperty: 'id';
        type: 'object';
        visibility: 'NORMAL';
    };
}
export declare const TrackingItem: TrackingItem;
