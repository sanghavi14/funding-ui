import type { PropertyDef as $PropertyDef } from '@osdk/client';
import { $osdkMetadata } from '../../OntologyMetadata.js';
import type { ObjectTypeDefinition as $ObjectTypeDefinition } from '@osdk/client';
import type { ObjectSet as $ObjectSet, Osdk as $Osdk, PropertyValueWireToClient as $PropType } from '@osdk/client';
export declare namespace AppEvent {
    type PropertyKeys = 'eventDateTime' | 'eventName' | 'eventReason' | 'eventStatus' | 'eventType' | 'id' | 'loanNumber';
    type Links = {};
    interface Props {
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Event Date Time'
         */
        readonly eventDateTime: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Event Name'
         */
        readonly eventName: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Event Reason'
         */
        readonly eventReason: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Event Status'
         */
        readonly eventStatus: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Event Type'
         */
        readonly eventType: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Id'
         */
        readonly id: $PropType['string'];
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Loan Number'
         */
        readonly loanNumber: $PropType['string'] | undefined;
    }
    type StrictProps = Props;
    interface ObjectSet extends $ObjectSet<AppEvent, AppEvent.ObjectSet> {
    }
    type OsdkInstance<OPTIONS extends never | '$rid' = never, K extends keyof AppEvent.Props = keyof AppEvent.Props> = $Osdk.Instance<AppEvent, OPTIONS, K>;
    /** @deprecated use OsdkInstance */
    type OsdkObject<OPTIONS extends never | '$rid' = never, K extends keyof AppEvent.Props = keyof AppEvent.Props> = OsdkInstance<OPTIONS, K>;
}
export interface AppEvent extends $ObjectTypeDefinition {
    osdkMetadata: typeof $osdkMetadata;
    type: 'object';
    apiName: 'AppEvent';
    primaryKeyApiName: 'id';
    primaryKeyType: 'string';
    __DefinitionMetadata?: {
        objectSet: AppEvent.ObjectSet;
        props: AppEvent.Props;
        linksType: AppEvent.Links;
        strictProps: AppEvent.StrictProps;
        apiName: 'AppEvent';
        description: '';
        displayName: 'App Event';
        icon: {
            type: 'blueprint';
            color: '#4C90F0';
            name: 'cube';
        };
        implements: [];
        interfaceMap: {};
        inverseInterfaceMap: {};
        links: {};
        pluralDisplayName: 'App Events';
        primaryKeyApiName: 'id';
        primaryKeyType: 'string';
        properties: {
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Event Date Time'
             */
            eventDateTime: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Event Name'
             */
            eventName: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Event Reason'
             */
            eventReason: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Event Status'
             */
            eventStatus: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Event Type'
             */
            eventType: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Id'
             */
            id: $PropertyDef<'string', 'non-nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Loan Number'
             */
            loanNumber: $PropertyDef<'string', 'nullable', 'single'>;
        };
        rid: 'ri.ontology.main.object-type.d593335e-5cd4-4c3d-bf95-c2e2436d89bb';
        status: 'EXPERIMENTAL';
        titleProperty: 'id';
        type: 'object';
        visibility: 'NORMAL';
    };
}
export declare const AppEvent: AppEvent;
