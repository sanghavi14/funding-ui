import type { QueryDefinition, QueryParam, QueryResult, VersionBound } from '@osdk/client';
import type { $ExpectedClientVersion } from '../../OntologyMetadata.js';
import { $osdkMetadata } from '../../OntologyMetadata.js';
import type { LoanInformation } from '../objects/LoanInformation.js';
export declare namespace getLoanDataByLoanNumber {
    interface Signature {
        (query: getLoanDataByLoanNumber.Parameters): Promise<getLoanDataByLoanNumber.ReturnType>;
    }
    interface Parameters {
        /**
         * (no ontology metadata)
         */
        readonly loanNum: QueryParam.PrimitiveType<'string'>;
    }
    type ReturnType = QueryResult.ObjectType<LoanInformation>;
}
export interface getLoanDataByLoanNumber extends QueryDefinition<getLoanDataByLoanNumber.Signature>, VersionBound<$ExpectedClientVersion> {
    __DefinitionMetadata?: {
        apiName: 'getLoanDataByLoanNumber';
        displayName: 'getLoanDataByLoanNum_Export';
        rid: 'ri.function-registry.main.function.f7585c95-bcda-4de8-bf26-d0e0853bf676';
        type: 'query';
        version: '0.45.0';
        isFixedVersion: false;
        parameters: {
            /**
             * (no ontology metadata)
             */
            loanNum: {
                nullable: false;
                type: 'string';
            };
        };
        output: {
            nullable: false;
            object: 'LoanInformation';
            type: 'object';
            __OsdkTargetType?: LoanInformation;
        };
        signature: getLoanDataByLoanNumber.Signature;
    };
    apiName: 'getLoanDataByLoanNumber';
    type: 'query';
    version: '0.45.0';
    osdkMetadata: typeof $osdkMetadata;
}
export declare const getLoanDataByLoanNumber: getLoanDataByLoanNumber;
