import type { QueryDefinition, QueryParam, QueryResult, VersionBound } from '@osdk/client';
import type { $ExpectedClientVersion } from '../../OntologyMetadata.js';
import { $osdkMetadata } from '../../OntologyMetadata.js';
import type { AppEvent } from '../objects/AppEvent.js';
import type { WireBankContact } from '../objects/WireBankContact.js';
import type { TrackingItem } from '../objects/TrackingItem.js';
import type { CashToCloseData } from '../objects/CashToCloseData.js';
import type { Fraudguard } from '../objects/Fraudguard.js';
import type { ComplianceEase } from '../objects/ComplianceEase.js';
export declare namespace getLoanEventsForAgent {
    interface Signature {
        (query: getLoanEventsForAgent.Parameters): Promise<getLoanEventsForAgent.ReturnType>;
    }
    interface Parameters {
        /**
         * (no ontology metadata)
         */
        readonly loanNumber: QueryParam.PrimitiveType<'string'>;
    }
    interface ReturnType {
        appEvents: Array<QueryResult.ObjectType<AppEvent>>;
        cashToCloseItems: Array<QueryResult.ObjectType<CashToCloseData>>;
        complianceEaseItems: Array<QueryResult.ObjectType<ComplianceEase>>;
        loanNumber: QueryResult.PrimitiveType<'string'>;
        notaryFraudGuardItems: Array<QueryResult.ObjectType<Fraudguard>>;
        totalEventsCount: QueryResult.PrimitiveType<'integer'>;
        trackingItems: Array<QueryResult.ObjectType<TrackingItem>>;
        wireBankEvents: Array<QueryResult.ObjectType<WireBankContact>>;
    }
}
export interface getLoanEventsForAgent extends QueryDefinition<getLoanEventsForAgent.Signature>, VersionBound<$ExpectedClientVersion> {
    __DefinitionMetadata?: {
        apiName: 'getLoanEventsForAgent';
        displayName: 'getLoanEventsForAgent_Export';
        rid: 'ri.function-registry.main.function.3d7edc6f-8d6e-47b4-83d0-939f89e7b98d';
        type: 'query';
        version: '0.45.0';
        isFixedVersion: false;
        parameters: {
            /**
             * (no ontology metadata)
             */
            loanNumber: {
                nullable: false;
                type: 'string';
            };
        };
        output: {
            nullable: false;
            struct: {
                loanNumber: {
                    type: 'string';
                    nullable: false;
                };
                appEvents: {
                    array: {
                        type: 'object';
                        object: 'AppEvent';
                        nullable: false;
                    };
                    type: 'array';
                    nullable: false;
                };
                wireBankEvents: {
                    array: {
                        type: 'object';
                        object: 'WireBankContact';
                        nullable: false;
                    };
                    type: 'array';
                    nullable: false;
                };
                trackingItems: {
                    array: {
                        type: 'object';
                        object: 'TrackingItem';
                        nullable: false;
                    };
                    type: 'array';
                    nullable: false;
                };
                cashToCloseItems: {
                    array: {
                        type: 'object';
                        object: 'CashToCloseData';
                        nullable: false;
                    };
                    type: 'array';
                    nullable: false;
                };
                notaryFraudGuardItems: {
                    array: {
                        type: 'object';
                        object: 'Fraudguard';
                        nullable: false;
                    };
                    type: 'array';
                    nullable: false;
                };
                complianceEaseItems: {
                    array: {
                        type: 'object';
                        object: 'ComplianceEase';
                        nullable: false;
                    };
                    type: 'array';
                    nullable: false;
                };
                totalEventsCount: {
                    type: 'integer';
                    nullable: false;
                };
            };
            type: 'struct';
        };
        signature: getLoanEventsForAgent.Signature;
    };
    apiName: 'getLoanEventsForAgent';
    type: 'query';
    version: '0.45.0';
    osdkMetadata: typeof $osdkMetadata;
}
export declare const getLoanEventsForAgent: getLoanEventsForAgent;
