import type { QueryDefinition, QueryParam, QueryResult, VersionBound } from '@osdk/client';
import type { $ExpectedClientVersion } from '../../OntologyMetadata.js';
import { $osdkMetadata } from '../../OntologyMetadata.js';
export declare namespace getTrackingItemsIntent {
    interface Signature {
        (query: getTrackingItemsIntent.Parameters): Promise<getTrackingItemsIntent.ReturnType>;
    }
    interface Parameters {
        /**
         * (no ontology metadata)
         */
        readonly loanNumber: QueryParam.PrimitiveType<'string'>;
    }
    type ReturnType = QueryResult.PrimitiveType<'string'>;
}
export interface getTrackingItemsIntent extends QueryDefinition<getTrackingItemsIntent.Signature>, VersionBound<$ExpectedClientVersion> {
    __DefinitionMetadata?: {
        apiName: 'getTrackingItemsIntent';
        displayName: 'getTrackingItemsIntent_Export';
        rid: 'ri.function-registry.main.function.80b5617d-c02c-4cb7-a0fc-19278d3a71d0';
        type: 'query';
        version: '0.45.0';
        isFixedVersion: false;
        parameters: {
            /**
             * (no ontology metadata)
             */
            loanNumber: {
                nullable: false;
                type: 'string';
            };
        };
        output: {
            nullable: false;
            type: 'string';
        };
        signature: getTrackingItemsIntent.Signature;
    };
    apiName: 'getTrackingItemsIntent';
    type: 'query';
    version: '0.45.0';
    osdkMetadata: typeof $osdkMetadata;
}
export declare const getTrackingItemsIntent: getTrackingItemsIntent;
