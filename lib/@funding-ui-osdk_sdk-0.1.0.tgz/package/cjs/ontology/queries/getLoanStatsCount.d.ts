import type { QueryDefinition, QueryResult, VersionBound } from '@osdk/client';
import type { $ExpectedClientVersion } from '../../OntologyMetadata.js';
import { $osdkMetadata } from '../../OntologyMetadata.js';
export declare namespace getLoanStatsCount {
    interface Signature {
        (): Promise<getLoanStatsCount.ReturnType>;
    }
    type ReturnType = QueryResult.TwoDimensionalAggregationType<'string', 'double'>;
}
export interface getLoanStatsCount extends QueryDefinition<getLoanStatsCount.Signature>, VersionBound<$ExpectedClientVersion> {
    __DefinitionMetadata?: {
        apiName: 'getLoanStatsCount';
        displayName: 'getLoanStats_Export';
        rid: 'ri.function-registry.main.function.e6d087ee-a0d3-4798-8563-f13987eb1ee1';
        type: 'query';
        version: '0.45.0';
        isFixedVersion: false;
        parameters: {};
        output: {
            nullable: false;
            twoDimensionalAggregation: {
                keyType: 'string';
                valueType: 'double';
            };
            type: 'twoDimensionalAggregation';
        };
        signature: getLoanStatsCount.Signature;
    };
    apiName: 'getLoanStatsCount';
    type: 'query';
    version: '0.45.0';
    osdkMetadata: typeof $osdkMetadata;
}
export declare const getLoanStatsCount: getLoanStatsCount;
