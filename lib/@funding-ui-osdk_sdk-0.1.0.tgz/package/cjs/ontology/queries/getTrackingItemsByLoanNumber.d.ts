import type { QueryDefinition, QueryParam, QueryResult, VersionBound } from '@osdk/client';
import type { $ExpectedClientVersion } from '../../OntologyMetadata.js';
import { $osdkMetadata } from '../../OntologyMetadata.js';
import type { TrackingItem } from '../objects/TrackingItem.js';
export declare namespace getTrackingItemsByLoanNumber {
    interface Signature {
        (query: getTrackingItemsByLoanNumber.Parameters): Promise<getTrackingItemsByLoanNumber.ReturnType>;
    }
    interface Parameters {
        /**
         * (no ontology metadata)
         */
        readonly loanNum: QueryParam.PrimitiveType<'string'>;
    }
    type ReturnType = Array<QueryResult.ObjectType<TrackingItem>>;
}
export interface getTrackingItemsByLoanNumber extends QueryDefinition<getTrackingItemsByLoanNumber.Signature>, VersionBound<$ExpectedClientVersion> {
    __DefinitionMetadata?: {
        apiName: 'getTrackingItemsByLoanNumber';
        displayName: 'getTrackingItemsByLoanNum_Export';
        rid: 'ri.function-registry.main.function.e9913127-e798-4cc1-ad71-1b8a0cdd966d';
        type: 'query';
        version: '0.45.0';
        isFixedVersion: false;
        parameters: {
            /**
             * (no ontology metadata)
             */
            loanNum: {
                nullable: false;
                type: 'string';
            };
        };
        output: {
            array: {
                type: 'object';
                object: 'TrackingItem';
                nullable: false;
            };
            nullable: false;
            type: 'array';
        };
        signature: getTrackingItemsByLoanNumber.Signature;
    };
    apiName: 'getTrackingItemsByLoanNumber';
    type: 'query';
    version: '0.45.0';
    osdkMetadata: typeof $osdkMetadata;
}
export declare const getTrackingItemsByLoanNumber: getTrackingItemsByLoanNumber;
