import type { QueryDefinition, QueryParam, QueryResult, VersionBound } from '@osdk/client';
import type { $ExpectedClientVersion } from '../../OntologyMetadata.js';
import { $osdkMetadata } from '../../OntologyMetadata.js';
export declare namespace parseAIPFilterOutput {
    interface Signature {
        (query: parseAIPFilterOutput.Parameters): Promise<parseAIPFilterOutput.ReturnType>;
    }
    interface Parameters {
        /**
         * (no ontology metadata)
         */
        readonly jsonString: QueryParam.PrimitiveType<'string'>;
    }
    interface ReturnType {
        app_event_ids: Array<QueryResult.PrimitiveType<'string'>>;
        compliance_ease_ids: Array<QueryResult.PrimitiveType<'string'>>;
        tracking_item_ids: Array<QueryResult.PrimitiveType<'string'>>;
        wire_bank_ids: Array<QueryResult.PrimitiveType<'string'>>;
    }
}
export interface parseAIPFilterOutput extends QueryDefinition<parseAIPFilterOutput.Signature>, VersionBound<$ExpectedClientVersion> {
    __DefinitionMetadata?: {
        apiName: 'parseAIPFilterOutput';
        displayName: 'parseAipFilterOutput_Export';
        rid: 'ri.function-registry.main.function.623ff674-bd9a-42f7-af27-b93e60eabbbe';
        type: 'query';
        version: '0.45.0';
        isFixedVersion: false;
        parameters: {
            /**
             * (no ontology metadata)
             */
            jsonString: {
                nullable: false;
                type: 'string';
            };
        };
        output: {
            nullable: false;
            struct: {
                tracking_item_ids: {
                    array: {
                        type: 'string';
                        nullable: false;
                    };
                    type: 'array';
                    nullable: false;
                };
                app_event_ids: {
                    array: {
                        type: 'string';
                        nullable: false;
                    };
                    type: 'array';
                    nullable: false;
                };
                wire_bank_ids: {
                    array: {
                        type: 'string';
                        nullable: false;
                    };
                    type: 'array';
                    nullable: false;
                };
                compliance_ease_ids: {
                    array: {
                        type: 'string';
                        nullable: false;
                    };
                    type: 'array';
                    nullable: false;
                };
            };
            type: 'struct';
        };
        signature: parseAIPFilterOutput.Signature;
    };
    apiName: 'parseAIPFilterOutput';
    type: 'query';
    version: '0.45.0';
    osdkMetadata: typeof $osdkMetadata;
}
export declare const parseAIPFilterOutput: parseAIPFilterOutput;
