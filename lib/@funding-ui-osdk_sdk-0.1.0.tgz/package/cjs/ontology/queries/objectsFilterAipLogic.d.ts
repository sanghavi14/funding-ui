import type { QueryDefinition, QueryParam, QueryResult, VersionBound } from '@osdk/client';
import type { $ExpectedClientVersion } from '../../OntologyMetadata.js';
import { $osdkMetadata } from '../../OntologyMetadata.js';
import type { WireBankContact } from '../objects/WireBankContact.js';
import type { ComplianceEase } from '../objects/ComplianceEase.js';
import type { TrackingItem } from '../objects/TrackingItem.js';
import type { AppEvent } from '../objects/AppEvent.js';
export declare namespace objectsFilterAipLogic {
    interface Signature {
        (query: objectsFilterAipLogic.Parameters): Promise<objectsFilterAipLogic.ReturnType>;
    }
    interface Parameters {
        /**
         * (no ontology metadata)
         */
        readonly appEventsBaseline: QueryParam.ObjectSetType<AppEvent>;
        /**
         * (no ontology metadata)
         */
        readonly complianceEaseBaseline: QueryParam.ObjectSetType<ComplianceEase>;
        /**
         * (no ontology metadata)
         */
        readonly trackingItemsBaseline: QueryParam.ObjectSetType<TrackingItem>;
        /**
         * (no ontology metadata)
         */
        readonly userQuery: QueryParam.PrimitiveType<'string'>;
        /**
         * (no ontology metadata)
         */
        readonly wireBanksBaseline: QueryParam.ObjectSetType<WireBankContact>;
    }
    interface ReturnType {
        payload: QueryResult.PrimitiveType<'string'>;
    }
}
export interface objectsFilterAipLogic extends QueryDefinition<objectsFilterAipLogic.Signature>, VersionBound<$ExpectedClientVersion> {
    __DefinitionMetadata?: {
        apiName: 'objectsFilterAipLogic';
        displayName: 'Objects Filter AIP Logic';
        rid: 'ri.function-registry.main.function.18d0cb02-aa59-43ea-b930-addc7bd8332b';
        type: 'query';
        version: '3.0.0';
        isFixedVersion: false;
        parameters: {
            /**
             * (no ontology metadata)
             */
            appEventsBaseline: {
                description: '';
                nullable: false;
                objectSet: 'AppEvent';
                type: 'objectSet';
                __OsdkTargetType?: AppEvent;
            };
            /**
             * (no ontology metadata)
             */
            complianceEaseBaseline: {
                description: '';
                nullable: false;
                objectSet: 'ComplianceEase';
                type: 'objectSet';
                __OsdkTargetType?: ComplianceEase;
            };
            /**
             * (no ontology metadata)
             */
            trackingItemsBaseline: {
                description: '';
                nullable: false;
                objectSet: 'TrackingItem';
                type: 'objectSet';
                __OsdkTargetType?: TrackingItem;
            };
            /**
             * (no ontology metadata)
             */
            userQuery: {
                description: '';
                nullable: false;
                type: 'string';
            };
            /**
             * (no ontology metadata)
             */
            wireBanksBaseline: {
                description: '';
                nullable: false;
                objectSet: 'WireBankContact';
                type: 'objectSet';
                __OsdkTargetType?: WireBankContact;
            };
        };
        output: {
            nullable: false;
            struct: {
                payload: {
                    type: 'string';
                    nullable: false;
                };
            };
            type: 'struct';
        };
        signature: objectsFilterAipLogic.Signature;
    };
    apiName: 'objectsFilterAipLogic';
    type: 'query';
    version: '3.0.0';
    osdkMetadata: typeof $osdkMetadata;
}
export declare const objectsFilterAipLogic: objectsFilterAipLogic;
