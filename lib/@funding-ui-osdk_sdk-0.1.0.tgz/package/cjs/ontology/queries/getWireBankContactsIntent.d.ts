import type { QueryDefinition, QueryParam, QueryResult, VersionBound } from '@osdk/client';
import type { $ExpectedClientVersion } from '../../OntologyMetadata.js';
import { $osdkMetadata } from '../../OntologyMetadata.js';
export declare namespace getWireBankContactsIntent {
    interface Signature {
        (query: getWireBankContactsIntent.Parameters): Promise<getWireBankContactsIntent.ReturnType>;
    }
    interface Parameters {
        /**
         * (no ontology metadata)
         */
        readonly loanNumber: QueryParam.PrimitiveType<'string'>;
    }
    type ReturnType = QueryResult.PrimitiveType<'string'>;
}
export interface getWireBankContactsIntent extends QueryDefinition<getWireBankContactsIntent.Signature>, VersionBound<$ExpectedClientVersion> {
    __DefinitionMetadata?: {
        apiName: 'getWireBankContactsIntent';
        displayName: 'getWireBankContactsIntent_Export';
        rid: 'ri.function-registry.main.function.61850327-1784-453d-a073-eee997bc8f0f';
        type: 'query';
        version: '0.45.0';
        isFixedVersion: false;
        parameters: {
            /**
             * (no ontology metadata)
             */
            loanNumber: {
                nullable: false;
                type: 'string';
            };
        };
        output: {
            nullable: false;
            type: 'string';
        };
        signature: getWireBankContactsIntent.Signature;
    };
    apiName: 'getWireBankContactsIntent';
    type: 'query';
    version: '0.45.0';
    osdkMetadata: typeof $osdkMetadata;
}
export declare const getWireBankContactsIntent: getWireBankContactsIntent;
