import type { QueryDefinition, QueryParam, QueryResult, VersionBound } from '@osdk/client';
import type { $ExpectedClientVersion } from '../../OntologyMetadata.js';
import { $osdkMetadata } from '../../OntologyMetadata.js';
export declare namespace getAppEventsIntent {
    interface Signature {
        (query: getAppEventsIntent.Parameters): Promise<getAppEventsIntent.ReturnType>;
    }
    interface Parameters {
        /**
         * (no ontology metadata)
         */
        readonly loanNumber: QueryParam.PrimitiveType<'string'>;
    }
    type ReturnType = QueryResult.PrimitiveType<'string'>;
}
export interface getAppEventsIntent extends QueryDefinition<getAppEventsIntent.Signature>, VersionBound<$ExpectedClientVersion> {
    __DefinitionMetadata?: {
        apiName: 'getAppEventsIntent';
        displayName: 'getAppEventsIntent_Export';
        rid: 'ri.function-registry.main.function.151fec84-2a8e-4ce6-808f-266edb1b889e';
        type: 'query';
        version: '0.45.0';
        isFixedVersion: false;
        parameters: {
            /**
             * (no ontology metadata)
             */
            loanNumber: {
                nullable: false;
                type: 'string';
            };
        };
        output: {
            nullable: false;
            type: 'string';
        };
        signature: getAppEventsIntent.Signature;
    };
    apiName: 'getAppEventsIntent';
    type: 'query';
    version: '0.45.0';
    osdkMetadata: typeof $osdkMetadata;
}
export declare const getAppEventsIntent: getAppEventsIntent;
