import type { QueryDefinition, QueryParam, QueryResult, VersionBound } from '@osdk/client';
import type { $ExpectedClientVersion } from '../../OntologyMetadata.js';
import { $osdkMetadata } from '../../OntologyMetadata.js';
import type { AppEvent } from '../objects/AppEvent.js';
export declare namespace getAppEventsByLoanNumber {
    interface Signature {
        (query: getAppEventsByLoanNumber.Parameters): Promise<getAppEventsByLoanNumber.ReturnType>;
    }
    interface Parameters {
        /**
         * (no ontology metadata)
         */
        readonly loanNum: QueryParam.PrimitiveType<'string'>;
    }
    type ReturnType = Array<QueryResult.ObjectType<AppEvent>>;
}
export interface getAppEventsByLoanNumber extends QueryDefinition<getAppEventsByLoanNumber.Signature>, VersionBound<$ExpectedClientVersion> {
    __DefinitionMetadata?: {
        apiName: 'getAppEventsByLoanNumber';
        displayName: 'getAppEventsByLoanNum_Export';
        rid: 'ri.function-registry.main.function.998743b7-0232-4fcb-9127-8781121433d0';
        type: 'query';
        version: '0.45.0';
        isFixedVersion: false;
        parameters: {
            /**
             * (no ontology metadata)
             */
            loanNum: {
                nullable: false;
                type: 'string';
            };
        };
        output: {
            array: {
                type: 'object';
                object: 'AppEvent';
                nullable: false;
            };
            nullable: false;
            type: 'array';
        };
        signature: getAppEventsByLoanNumber.Signature;
    };
    apiName: 'getAppEventsByLoanNumber';
    type: 'query';
    version: '0.45.0';
    osdkMetadata: typeof $osdkMetadata;
}
export declare const getAppEventsByLoanNumber: getAppEventsByLoanNumber;
