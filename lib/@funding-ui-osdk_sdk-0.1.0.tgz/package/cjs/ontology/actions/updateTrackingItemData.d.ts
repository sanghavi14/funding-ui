import type { ActionDefinition, ActionMetadata, ActionParam, ActionReturnTypeForOptions, ApplyActionOptions, ApplyBatchActionOptions } from '@osdk/client';
import { $osdkMetadata } from '../../OntologyMetadata.js';
import type { TrackingItem } from '../objects/TrackingItem.js';
export declare namespace updateTrackingItemData {
    type ParamsDefinition = {
        dueDate: {
            description: undefined;
            multiplicity: false;
            nullable: false;
            type: 'datetime';
        };
        hasExcp: {
            description: undefined;
            multiplicity: false;
            nullable: false;
            type: 'string';
        };
        loanNum: {
            description: undefined;
            multiplicity: false;
            nullable: false;
            type: 'string';
        };
        priorTo: {
            description: undefined;
            multiplicity: false;
            nullable: false;
            type: 'string';
        };
        tiData: {
            description: undefined;
            multiplicity: false;
            nullable: false;
            type: ActionMetadata.DataType.Object<TrackingItem>;
        };
        tiName: {
            description: undefined;
            multiplicity: false;
            nullable: false;
            type: 'string';
        };
        tiStatus: {
            description: undefined;
            multiplicity: false;
            nullable: false;
            type: 'string';
        };
    };
    /**
     * Update Tracking Item Data
     */
    interface Params {
        readonly dueDate: ActionParam.PrimitiveType<'datetime'>;
        readonly hasExcp: ActionParam.PrimitiveType<'string'>;
        readonly loanNum: ActionParam.PrimitiveType<'string'>;
        readonly priorTo: ActionParam.PrimitiveType<'string'>;
        readonly tiData: ActionParam.ObjectType<TrackingItem>;
        readonly tiName: ActionParam.PrimitiveType<'string'>;
        readonly tiStatus: ActionParam.PrimitiveType<'string'>;
    }
    interface Signatures {
        /**
         * Update Tracking Item Data
         */
        applyAction<OP extends ApplyActionOptions>(args: updateTrackingItemData.Params, options?: OP): Promise<ActionReturnTypeForOptions<OP>>;
        batchApplyAction<OP extends ApplyBatchActionOptions>(args: ReadonlyArray<updateTrackingItemData.Params>, options?: OP): Promise<ActionReturnTypeForOptions<OP>>;
    }
}
/**
 * Update Tracking Item Data
 * @param {ActionParam.PrimitiveType<"datetime">} dueDate
 * @param {ActionParam.PrimitiveType<"string">} hasExcp
 * @param {ActionParam.PrimitiveType<"string">} loanNum
 * @param {ActionParam.PrimitiveType<"string">} priorTo
 * @param {ActionParam.ObjectType<TrackingItem>} tiData
 * @param {ActionParam.PrimitiveType<"string">} tiName
 * @param {ActionParam.PrimitiveType<"string">} tiStatus
 */
export interface updateTrackingItemData extends ActionDefinition<updateTrackingItemData.Signatures> {
    __DefinitionMetadata?: {
        apiName: 'updateTrackingItemData';
        description: 'Update Tracking Item Data';
        displayName: 'Update Tracking Item Data';
        modifiedEntities: {};
        parameters: updateTrackingItemData.ParamsDefinition;
        rid: 'ri.actions.main.action-type.6fbd46cf-c2a1-4fcc-9f64-c080d4774df7';
        status: 'EXPERIMENTAL';
        type: 'action';
        unsanitizedApiName: 'update-tracking-item-data';
        signatures: updateTrackingItemData.Signatures;
    };
    apiName: 'updateTrackingItemData';
    type: 'action';
    unsanitizedApiName: 'update-tracking-item-data';
    osdkMetadata: typeof $osdkMetadata;
}
export declare const updateTrackingItemData: updateTrackingItemData;
