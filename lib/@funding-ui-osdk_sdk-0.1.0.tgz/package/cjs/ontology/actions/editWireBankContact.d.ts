import type { ActionDefinition, ActionMetadata, ActionParam, ActionReturnTypeForOptions, ApplyActionOptions, ApplyBatchActionOptions } from '@osdk/client';
import { $osdkMetadata } from '../../OntologyMetadata.js';
import type { WireBankContact } from '../objects/WireBankContact.js';
export declare namespace editWireBankContact {
    type ParamsDefinition = {
        abaNum: {
            description: undefined;
            multiplicity: false;
            nullable: false;
            type: 'integer';
        };
        accountName: {
            description: undefined;
            multiplicity: false;
            nullable: false;
            type: 'string';
        };
        accountNum: {
            description: undefined;
            multiplicity: false;
            nullable: false;
            type: 'long';
        };
        addressType: {
            description: undefined;
            multiplicity: false;
            nullable: true;
            type: 'string';
        };
        city: {
            description: undefined;
            multiplicity: false;
            nullable: false;
            type: 'string';
        };
        loanNumber: {
            description: undefined;
            multiplicity: false;
            nullable: false;
            type: 'string';
        };
        name: {
            description: undefined;
            multiplicity: false;
            nullable: false;
            type: 'string';
        };
        shortName: {
            description: undefined;
            multiplicity: false;
            nullable: false;
            type: 'string';
        };
        state: {
            description: undefined;
            multiplicity: false;
            nullable: false;
            type: 'string';
        };
        WireBankContact: {
            description: undefined;
            multiplicity: false;
            nullable: false;
            type: ActionMetadata.DataType.Object<WireBankContact>;
        };
        zipPlus: {
            description: undefined;
            multiplicity: false;
            nullable: false;
            type: 'string';
        };
    };
    interface Params {
        readonly abaNum: ActionParam.PrimitiveType<'integer'>;
        readonly accountName: ActionParam.PrimitiveType<'string'>;
        readonly accountNum: ActionParam.PrimitiveType<'long'>;
        readonly addressType?: ActionParam.PrimitiveType<'string'> | null;
        readonly city: ActionParam.PrimitiveType<'string'>;
        readonly loanNumber: ActionParam.PrimitiveType<'string'>;
        readonly name: ActionParam.PrimitiveType<'string'>;
        readonly shortName: ActionParam.PrimitiveType<'string'>;
        readonly state: ActionParam.PrimitiveType<'string'>;
        readonly WireBankContact: ActionParam.ObjectType<WireBankContact>;
        readonly zipPlus: ActionParam.PrimitiveType<'string'>;
    }
    interface Signatures {
        applyAction<OP extends ApplyActionOptions>(args: editWireBankContact.Params, options?: OP): Promise<ActionReturnTypeForOptions<OP>>;
        batchApplyAction<OP extends ApplyBatchActionOptions>(args: ReadonlyArray<editWireBankContact.Params>, options?: OP): Promise<ActionReturnTypeForOptions<OP>>;
    }
}
/**
 * @param {ActionParam.PrimitiveType<"integer">} abaNum
 * @param {ActionParam.PrimitiveType<"string">} accountName
 * @param {ActionParam.PrimitiveType<"long">} accountNum
 * @param {ActionParam.PrimitiveType<"string">} [addressType]
 * @param {ActionParam.PrimitiveType<"string">} city
 * @param {ActionParam.PrimitiveType<"string">} loanNumber
 * @param {ActionParam.PrimitiveType<"string">} name
 * @param {ActionParam.PrimitiveType<"string">} shortName
 * @param {ActionParam.PrimitiveType<"string">} state
 * @param {ActionParam.ObjectType<WireBankContact>} WireBankContact
 * @param {ActionParam.PrimitiveType<"string">} zipPlus
 */
export interface editWireBankContact extends ActionDefinition<editWireBankContact.Signatures> {
    __DefinitionMetadata?: {
        apiName: 'editWireBankContact';
        displayName: 'Edit Wire Bank Contact';
        modifiedEntities: {
            WireBankContact: {
                created: false;
                modified: true;
            };
        };
        parameters: editWireBankContact.ParamsDefinition;
        rid: 'ri.actions.main.action-type.eb929af2-5965-441f-9993-0d76b4848582';
        status: 'EXPERIMENTAL';
        type: 'action';
        unsanitizedApiName: 'edit-wire-bank-contact';
        signatures: editWireBankContact.Signatures;
    };
    apiName: 'editWireBankContact';
    type: 'action';
    unsanitizedApiName: 'edit-wire-bank-contact';
    osdkMetadata: typeof $osdkMetadata;
}
export declare const editWireBankContact: editWireBankContact;
