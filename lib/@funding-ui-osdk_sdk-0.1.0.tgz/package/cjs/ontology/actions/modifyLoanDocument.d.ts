import type { ActionDefinition, ActionMetadata, ActionParam, ActionReturnTypeForOptions, ApplyActionOptions, ApplyBatchActionOptions } from '@osdk/client';
import { $osdkMetadata } from '../../OntologyMetadata.js';
import type { LoanDocument } from '../objects/LoanDocument.js';
export declare namespace modifyLoanDocument {
    type ParamsDefinition = {
        description: {
            description: undefined;
            multiplicity: false;
            nullable: false;
            type: 'string';
        };
        documentName: {
            description: undefined;
            multiplicity: false;
            nullable: false;
            type: 'string';
        };
        loan_document: {
            description: undefined;
            multiplicity: false;
            nullable: false;
            type: ActionMetadata.DataType.Object<LoanDocument>;
        };
        loanDocuments: {
            description: undefined;
            multiplicity: false;
            nullable: false;
            type: 'attachment';
        };
        loanNumber: {
            description: undefined;
            multiplicity: false;
            nullable: false;
            type: 'string';
        };
    };
    interface Params {
        readonly description: ActionParam.PrimitiveType<'string'>;
        readonly documentName: ActionParam.PrimitiveType<'string'>;
        readonly loan_document: ActionParam.ObjectType<LoanDocument>;
        readonly loanDocuments: ActionParam.PrimitiveType<'attachment'>;
        readonly loanNumber: ActionParam.PrimitiveType<'string'>;
    }
    interface Signatures {
        applyAction<OP extends ApplyActionOptions>(args: modifyLoanDocument.Params, options?: OP): Promise<ActionReturnTypeForOptions<OP>>;
        batchApplyAction<OP extends ApplyBatchActionOptions>(args: ReadonlyArray<modifyLoanDocument.Params>, options?: OP): Promise<ActionReturnTypeForOptions<OP>>;
    }
}
/**
 * @param {ActionParam.PrimitiveType<"string">} description
 * @param {ActionParam.PrimitiveType<"string">} documentName
 * @param {ActionParam.ObjectType<LoanDocument>} loan_document
 * @param {ActionParam.PrimitiveType<"attachment">} loanDocuments
 * @param {ActionParam.PrimitiveType<"string">} loanNumber
 */
export interface modifyLoanDocument extends ActionDefinition<modifyLoanDocument.Signatures> {
    __DefinitionMetadata?: {
        apiName: 'modifyLoanDocument';
        displayName: 'Modify Loan Document';
        modifiedEntities: {
            LoanDocument: {
                created: false;
                modified: true;
            };
        };
        parameters: modifyLoanDocument.ParamsDefinition;
        rid: 'ri.actions.main.action-type.c484f88c-b88b-44af-adc0-9307031f87e8';
        status: 'EXPERIMENTAL';
        type: 'action';
        unsanitizedApiName: 'modify-loan-document';
        signatures: modifyLoanDocument.Signatures;
    };
    apiName: 'modifyLoanDocument';
    type: 'action';
    unsanitizedApiName: 'modify-loan-document';
    osdkMetadata: typeof $osdkMetadata;
}
export declare const modifyLoanDocument: modifyLoanDocument;
