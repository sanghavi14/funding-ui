import type { ActionDefinition, ActionParam, ActionReturnTypeForOptions, ApplyActionOptions, ApplyBatchActionOptions } from '@osdk/client';
import { $osdkMetadata } from '../../OntologyMetadata.js';
export declare namespace validateLoanFormat {
    type ParamsDefinition = {
        loanNumber: {
            description: undefined;
            multiplicity: false;
            nullable: false;
            type: 'string';
        };
    };
    interface Params {
        readonly loanNumber: ActionParam.PrimitiveType<'string'>;
    }
    interface Signatures {
        applyAction<OP extends ApplyActionOptions>(args: validateLoanFormat.Params, options?: OP): Promise<ActionReturnTypeForOptions<OP>>;
        batchApplyAction<OP extends ApplyBatchActionOptions>(args: ReadonlyArray<validateLoanFormat.Params>, options?: OP): Promise<ActionReturnTypeForOptions<OP>>;
    }
}
/**
 * @param {ActionParam.PrimitiveType<"string">} loanNumber
 */
export interface validateLoanFormat extends ActionDefinition<validateLoanFormat.Signatures> {
    __DefinitionMetadata?: {
        apiName: 'validateLoanFormat';
        displayName: 'validateLoanFormat';
        modifiedEntities: {};
        parameters: validateLoanFormat.ParamsDefinition;
        rid: 'ri.actions.main.action-type.63703a87-eba4-4f97-939a-72a1243c2cee';
        status: 'EXPERIMENTAL';
        type: 'action';
        unsanitizedApiName: 'validate-loan-format';
        signatures: validateLoanFormat.Signatures;
    };
    apiName: 'validateLoanFormat';
    type: 'action';
    unsanitizedApiName: 'validate-loan-format';
    osdkMetadata: typeof $osdkMetadata;
}
export declare const validateLoanFormat: validateLoanFormat;
