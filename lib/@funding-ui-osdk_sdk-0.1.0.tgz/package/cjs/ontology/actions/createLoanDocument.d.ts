import type { ActionDefinition, ActionParam, ActionReturnTypeForOptions, ApplyActionOptions, ApplyBatchActionOptions } from '@osdk/client';
import { $osdkMetadata } from '../../OntologyMetadata.js';
export declare namespace createLoanDocument {
    type ParamsDefinition = {
        description: {
            description: undefined;
            multiplicity: false;
            nullable: false;
            type: 'string';
        };
        documentName: {
            description: undefined;
            multiplicity: false;
            nullable: false;
            type: 'string';
        };
        loanDocuments: {
            description: undefined;
            multiplicity: false;
            nullable: false;
            type: 'attachment';
        };
        loanNumber: {
            description: undefined;
            multiplicity: false;
            nullable: false;
            type: 'string';
        };
    };
    interface Params {
        readonly description: ActionParam.PrimitiveType<'string'>;
        readonly documentName: ActionParam.PrimitiveType<'string'>;
        readonly loanDocuments: ActionParam.PrimitiveType<'attachment'>;
        readonly loanNumber: ActionParam.PrimitiveType<'string'>;
    }
    interface Signatures {
        applyAction<OP extends ApplyActionOptions>(args: createLoanDocument.Params, options?: OP): Promise<ActionReturnTypeForOptions<OP>>;
        batchApplyAction<OP extends ApplyBatchActionOptions>(args: ReadonlyArray<createLoanDocument.Params>, options?: OP): Promise<ActionReturnTypeForOptions<OP>>;
    }
}
/**
 * @param {ActionParam.PrimitiveType<"string">} description
 * @param {ActionParam.PrimitiveType<"string">} documentName
 * @param {ActionParam.PrimitiveType<"attachment">} loanDocuments
 * @param {ActionParam.PrimitiveType<"string">} loanNumber
 */
export interface createLoanDocument extends ActionDefinition<createLoanDocument.Signatures> {
    __DefinitionMetadata?: {
        apiName: 'createLoanDocument';
        displayName: 'Create Loan Document';
        modifiedEntities: {
            LoanDocument: {
                created: true;
                modified: false;
            };
        };
        parameters: createLoanDocument.ParamsDefinition;
        rid: 'ri.actions.main.action-type.17fe9020-4c12-44ff-b5f8-495038297192';
        status: 'EXPERIMENTAL';
        type: 'action';
        unsanitizedApiName: 'create-loan-document';
        signatures: createLoanDocument.Signatures;
    };
    apiName: 'createLoanDocument';
    type: 'action';
    unsanitizedApiName: 'create-loan-document';
    osdkMetadata: typeof $osdkMetadata;
}
export declare const createLoanDocument: createLoanDocument;
