import type { ActionDefinition, ActionParam, ActionReturnTypeForOptions, ApplyActionOptions, ApplyBatchActionOptions } from '@osdk/client';
import { $osdkMetadata } from '../../OntologyMetadata.js';
export declare namespace createLoanInformation {
    type ParamsDefinition = {
        borrowerName: {
            description: undefined;
            multiplicity: false;
            nullable: false;
            type: 'string';
        };
        cashout: {
            description: undefined;
            multiplicity: false;
            nullable: false;
            type: 'string';
        };
        cema: {
            description: undefined;
            multiplicity: false;
            nullable: false;
            type: 'string';
        };
        closingAgent: {
            description: undefined;
            multiplicity: false;
            nullable: false;
            type: 'string';
        };
        division: {
            description: undefined;
            multiplicity: false;
            nullable: false;
            type: 'string';
        };
        docType: {
            description: undefined;
            multiplicity: false;
            nullable: false;
            type: 'string';
        };
        id: {
            description: undefined;
            multiplicity: false;
            nullable: false;
            type: 'string';
        };
        interestRate: {
            description: undefined;
            multiplicity: false;
            nullable: false;
            type: 'double';
        };
        loanAmount: {
            description: undefined;
            multiplicity: false;
            nullable: false;
            type: 'integer';
        };
        loanStatus: {
            description: undefined;
            multiplicity: false;
            nullable: false;
            type: 'string';
        };
        loanType: {
            description: undefined;
            multiplicity: false;
            nullable: false;
            type: 'string';
        };
        occupancy: {
            description: undefined;
            multiplicity: false;
            nullable: false;
            type: 'string';
        };
        propertyAddress: {
            description: undefined;
            multiplicity: false;
            nullable: false;
            type: 'string';
        };
        propertyType: {
            description: undefined;
            multiplicity: false;
            nullable: false;
            type: 'string';
        };
        supportCenter: {
            description: undefined;
            multiplicity: false;
            nullable: false;
            type: 'string';
        };
    };
    interface Params {
        readonly borrowerName: ActionParam.PrimitiveType<'string'>;
        readonly cashout: ActionParam.PrimitiveType<'string'>;
        readonly cema: ActionParam.PrimitiveType<'string'>;
        readonly closingAgent: ActionParam.PrimitiveType<'string'>;
        readonly division: ActionParam.PrimitiveType<'string'>;
        readonly docType: ActionParam.PrimitiveType<'string'>;
        readonly id: ActionParam.PrimitiveType<'string'>;
        readonly interestRate: ActionParam.PrimitiveType<'double'>;
        readonly loanAmount: ActionParam.PrimitiveType<'integer'>;
        readonly loanStatus: ActionParam.PrimitiveType<'string'>;
        readonly loanType: ActionParam.PrimitiveType<'string'>;
        readonly occupancy: ActionParam.PrimitiveType<'string'>;
        readonly propertyAddress: ActionParam.PrimitiveType<'string'>;
        readonly propertyType: ActionParam.PrimitiveType<'string'>;
        readonly supportCenter: ActionParam.PrimitiveType<'string'>;
    }
    interface Signatures {
        applyAction<OP extends ApplyActionOptions>(args: createLoanInformation.Params, options?: OP): Promise<ActionReturnTypeForOptions<OP>>;
        batchApplyAction<OP extends ApplyBatchActionOptions>(args: ReadonlyArray<createLoanInformation.Params>, options?: OP): Promise<ActionReturnTypeForOptions<OP>>;
    }
}
/**
 * @param {ActionParam.PrimitiveType<"string">} borrowerName
 * @param {ActionParam.PrimitiveType<"string">} cashout
 * @param {ActionParam.PrimitiveType<"string">} cema
 * @param {ActionParam.PrimitiveType<"string">} closingAgent
 * @param {ActionParam.PrimitiveType<"string">} division
 * @param {ActionParam.PrimitiveType<"string">} docType
 * @param {ActionParam.PrimitiveType<"string">} id
 * @param {ActionParam.PrimitiveType<"double">} interestRate
 * @param {ActionParam.PrimitiveType<"integer">} loanAmount
 * @param {ActionParam.PrimitiveType<"string">} loanStatus
 * @param {ActionParam.PrimitiveType<"string">} loanType
 * @param {ActionParam.PrimitiveType<"string">} occupancy
 * @param {ActionParam.PrimitiveType<"string">} propertyAddress
 * @param {ActionParam.PrimitiveType<"string">} propertyType
 * @param {ActionParam.PrimitiveType<"string">} supportCenter
 */
export interface createLoanInformation extends ActionDefinition<createLoanInformation.Signatures> {
    __DefinitionMetadata?: {
        apiName: 'createLoanInformation';
        displayName: 'Create Loan Information';
        modifiedEntities: {
            LoanInformation: {
                created: true;
                modified: false;
            };
        };
        parameters: createLoanInformation.ParamsDefinition;
        rid: 'ri.actions.main.action-type.2e0335bf-56c5-4e2e-b9fe-8876389523d1';
        status: 'EXPERIMENTAL';
        type: 'action';
        unsanitizedApiName: 'create-loan-information';
        signatures: createLoanInformation.Signatures;
    };
    apiName: 'createLoanInformation';
    type: 'action';
    unsanitizedApiName: 'create-loan-information';
    osdkMetadata: typeof $osdkMetadata;
}
export declare const createLoanInformation: createLoanInformation;
