import type { ActionDefinition, ActionMetadata, ActionParam, ActionReturnTypeForOptions, ApplyActionOptions, ApplyBatchActionOptions } from '@osdk/client';
import { $osdkMetadata } from '../../OntologyMetadata.js';
import type { TrackingItem } from '../objects/TrackingItem.js';
export declare namespace markTiStatusAsComplete {
    type ParamsDefinition = {
        allTIs: {
            description: undefined;
            multiplicity: false;
            nullable: false;
            type: ActionMetadata.DataType.ObjectSet<TrackingItem>;
        };
    };
    interface Params {
        readonly allTIs: ActionParam.ObjectSetType<TrackingItem>;
    }
    interface Signatures {
        applyAction<OP extends ApplyActionOptions>(args: markTiStatusAsComplete.Params, options?: OP): Promise<ActionReturnTypeForOptions<OP>>;
        batchApplyAction<OP extends ApplyBatchActionOptions>(args: ReadonlyArray<markTiStatusAsComplete.Params>, options?: OP): Promise<ActionReturnTypeForOptions<OP>>;
    }
}
/**
 * @param {ActionParam.ObjectSetType<TrackingItem>} allTIs
 */
export interface markTiStatusAsComplete extends ActionDefinition<markTiStatusAsComplete.Signatures> {
    __DefinitionMetadata?: {
        apiName: 'markTiStatusAsComplete';
        displayName: 'Mark TI-Status As Complete';
        modifiedEntities: {};
        parameters: markTiStatusAsComplete.ParamsDefinition;
        rid: 'ri.actions.main.action-type.fd291593-ee67-4947-9a4f-f9c73b0e910a';
        status: 'EXPERIMENTAL';
        type: 'action';
        unsanitizedApiName: 'mark-ti-status-as-complete';
        signatures: markTiStatusAsComplete.Signatures;
    };
    apiName: 'markTiStatusAsComplete';
    type: 'action';
    unsanitizedApiName: 'mark-ti-status-as-complete';
    osdkMetadata: typeof $osdkMetadata;
}
export declare const markTiStatusAsComplete: markTiStatusAsComplete;
