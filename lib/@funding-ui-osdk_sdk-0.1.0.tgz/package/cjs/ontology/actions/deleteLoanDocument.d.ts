import type { ActionDefinition, ActionMetadata, ActionParam, ActionReturnTypeForOptions, ApplyActionOptions, ApplyBatchActionOptions } from '@osdk/client';
import { $osdkMetadata } from '../../OntologyMetadata.js';
import type { LoanDocument } from '../objects/LoanDocument.js';
export declare namespace deleteLoanDocument {
    type ParamsDefinition = {
        loan_document: {
            description: undefined;
            multiplicity: false;
            nullable: false;
            type: ActionMetadata.DataType.Object<LoanDocument>;
        };
        new_parameter: {
            description: undefined;
            multiplicity: false;
            nullable: false;
            type: 'string';
        };
    };
    interface Params {
        readonly loan_document: ActionParam.ObjectType<LoanDocument>;
        readonly new_parameter: ActionParam.PrimitiveType<'string'>;
    }
    interface Signatures {
        applyAction<OP extends ApplyActionOptions>(args: deleteLoanDocument.Params, options?: OP): Promise<ActionReturnTypeForOptions<OP>>;
        batchApplyAction<OP extends ApplyBatchActionOptions>(args: ReadonlyArray<deleteLoanDocument.Params>, options?: OP): Promise<ActionReturnTypeForOptions<OP>>;
    }
}
/**
 * @param {ActionParam.ObjectType<LoanDocument>} loan_document
 * @param {ActionParam.PrimitiveType<"string">} new_parameter
 */
export interface deleteLoanDocument extends ActionDefinition<deleteLoanDocument.Signatures> {
    __DefinitionMetadata?: {
        apiName: 'deleteLoanDocument';
        displayName: 'Delete Loan Document';
        modifiedEntities: {};
        parameters: deleteLoanDocument.ParamsDefinition;
        rid: 'ri.actions.main.action-type.c7ab76c8-d8f8-4bf7-bbde-160f9b35090e';
        status: 'EXPERIMENTAL';
        type: 'action';
        unsanitizedApiName: 'delete-loan-document';
        signatures: deleteLoanDocument.Signatures;
    };
    apiName: 'deleteLoanDocument';
    type: 'action';
    unsanitizedApiName: 'delete-loan-document';
    osdkMetadata: typeof $osdkMetadata;
}
export declare const deleteLoanDocument: deleteLoanDocument;
