import type { ActionDefinition, ActionMetadata, ActionParam, ActionReturnTypeForOptions, ApplyActionOptions, ApplyBatchActionOptions } from '@osdk/client';
import { $osdkMetadata } from '../../OntologyMetadata.js';
import type { WireBankContact } from '../objects/WireBankContact.js';
export declare namespace updateWireBankToJson {
    type ParamsDefinition = {
        abaNum: {
            description: undefined;
            multiplicity: false;
            nullable: false;
            type: 'integer';
        };
        acctName: {
            description: undefined;
            multiplicity: false;
            nullable: false;
            type: 'string';
        };
        acctNum: {
            description: undefined;
            multiplicity: false;
            nullable: false;
            type: 'long';
        };
        addType: {
            description: undefined;
            multiplicity: false;
            nullable: false;
            type: 'string';
        };
        city: {
            description: undefined;
            multiplicity: false;
            nullable: false;
            type: 'string';
        };
        loanNum: {
            description: undefined;
            multiplicity: false;
            nullable: false;
            type: 'string';
        };
        name: {
            description: undefined;
            multiplicity: false;
            nullable: false;
            type: 'string';
        };
        shortName: {
            description: undefined;
            multiplicity: false;
            nullable: false;
            type: 'string';
        };
        state: {
            description: undefined;
            multiplicity: false;
            nullable: false;
            type: 'string';
        };
        wireObj: {
            description: undefined;
            multiplicity: false;
            nullable: false;
            type: ActionMetadata.DataType.Object<WireBankContact>;
        };
        zipPlus: {
            description: undefined;
            multiplicity: false;
            nullable: false;
            type: 'string';
        };
    };
    interface Params {
        readonly abaNum: ActionParam.PrimitiveType<'integer'>;
        readonly acctName: ActionParam.PrimitiveType<'string'>;
        readonly acctNum: ActionParam.PrimitiveType<'long'>;
        readonly addType: ActionParam.PrimitiveType<'string'>;
        readonly city: ActionParam.PrimitiveType<'string'>;
        readonly loanNum: ActionParam.PrimitiveType<'string'>;
        readonly name: ActionParam.PrimitiveType<'string'>;
        readonly shortName: ActionParam.PrimitiveType<'string'>;
        readonly state: ActionParam.PrimitiveType<'string'>;
        readonly wireObj: ActionParam.ObjectType<WireBankContact>;
        readonly zipPlus: ActionParam.PrimitiveType<'string'>;
    }
    interface Signatures {
        applyAction<OP extends ApplyActionOptions>(args: updateWireBankToJson.Params, options?: OP): Promise<ActionReturnTypeForOptions<OP>>;
        batchApplyAction<OP extends ApplyBatchActionOptions>(args: ReadonlyArray<updateWireBankToJson.Params>, options?: OP): Promise<ActionReturnTypeForOptions<OP>>;
    }
}
/**
 * @param {ActionParam.PrimitiveType<"integer">} abaNum
 * @param {ActionParam.PrimitiveType<"string">} acctName
 * @param {ActionParam.PrimitiveType<"long">} acctNum
 * @param {ActionParam.PrimitiveType<"string">} addType
 * @param {ActionParam.PrimitiveType<"string">} city
 * @param {ActionParam.PrimitiveType<"string">} loanNum
 * @param {ActionParam.PrimitiveType<"string">} name
 * @param {ActionParam.PrimitiveType<"string">} shortName
 * @param {ActionParam.PrimitiveType<"string">} state
 * @param {ActionParam.ObjectType<WireBankContact>} wireObj
 * @param {ActionParam.PrimitiveType<"string">} zipPlus
 */
export interface updateWireBankToJson extends ActionDefinition<updateWireBankToJson.Signatures> {
    __DefinitionMetadata?: {
        apiName: 'updateWireBankToJson';
        displayName: 'Update WireBank to JSON';
        modifiedEntities: {};
        parameters: updateWireBankToJson.ParamsDefinition;
        rid: 'ri.actions.main.action-type.754b0c0d-fcad-494e-9362-7286f77da400';
        status: 'EXPERIMENTAL';
        type: 'action';
        unsanitizedApiName: 'update-wire-bank-to-json';
        signatures: updateWireBankToJson.Signatures;
    };
    apiName: 'updateWireBankToJson';
    type: 'action';
    unsanitizedApiName: 'update-wire-bank-to-json';
    osdkMetadata: typeof $osdkMetadata;
}
export declare const updateWireBankToJson: updateWireBankToJson;
