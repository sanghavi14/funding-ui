export type $ExpectedClientVersion = '2.16.0';
export declare const $osdkMetadata: {
    extraUserAgent: string;
};
export declare const $ontologyRid = "ri.ontology.main.ontology.3ca02c89-3deb-4e25-aeba-4fe247684080";
